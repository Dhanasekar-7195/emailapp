package com.example.emailApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.emailApp.entity.User;
import com.example.emailApp.service.EmailService;
import com.example.emailApp.service.UserService;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        userService.save(user);
        return ResponseEntity.ok("User registered successfully");
    }

//    @PostMapping("/forgot-password")
//    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
//        String email = request.get("email");
//        Optional<User> optionalUser = userService.findByEmail(email);
//        if (!optionalUser.isPresent()) {
//            return ResponseEntity.badRequest().body("User not found");
//        }
//        User user = optionalUser.get();
//        userService.createPasswordResetToken(user);
//        
//        String resetToken = user.getResetToken();
//
//        String resetLink = "http://localhost:8080/api/users/reset-password";
//        emailService.sendEmail(user.getEmail(), "Password Reset Request", "To reset your password, click the link below:\n" + resetLink);
//
//        Map<String, String> response = new HashMap<>();
//        response.put("message" , "Password reset link sent to your email");
//        response.put("reset token", resetToken);
//        return ResponseEntity.ok(response);
//        
//    }
    
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        Optional<User> optionalUser = userService.findByEmail(email);
        if (!optionalUser.isPresent()) {
            return ResponseEntity.badRequest().body("User not found");
        }
        User user = optionalUser.get();
        userService.createPasswordResetToken(user);
        
        String resetToken = user.getResetToken();

        String resetLink = "https://emailapp-insightful-hartebeest-kj.cfapps.us10-001.hana.ondemand.com/reset-password.html";
        emailService.sendEmail(user.getEmail(), "Password Reset Request", "To reset your password, click the link below:\n" + resetLink + "\n\ncode: " + resetToken);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Password reset link sent to your email");
        response.put("reset token", resetToken);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        String token = request.get("token");
        String newPassword = request.get("newPassword");
        String confirmPassword = request.get("confirmPassword");
        
    if (newPassword == null || confirmPassword == null || !newPassword.equals(confirmPassword)) {
        return ResponseEntity.badRequest().body("Passwords do not match");    	
        }

        Optional<User> optionalUser = userService.findByResetToken(token);
        if (!optionalUser.isPresent()) {
            return ResponseEntity.badRequest().body("Invalid token");
        }
        User user = optionalUser.get();
        userService.updatePassword(user, newPassword);

        return ResponseEntity.ok("Password reset successfully");
    }
}
